/* ======================= 斐波那契 递归 ======================= */

// function Fibonacci(n) {
//     if (n < 2) return n;
//     return Fibonacci(n - 1) + Fibonacci(n - 2);
// }

// for(let i = 1; i < 50; i++){
//     let startTime = new Date().getTime()
//     // console.log(Fibonacci(i))
//     Fibonacci(i)
//     let endTime = new Date().getTime()
//     console.log("第" + i + "次耗时：" + (endTime - startTime))
// }

/* ======================= 优化 斐波那契 数据缓存 ======================= */
// const num = [];

// function calcFib(n) {
//     if (n <= 2) {
//         num[n] = 1;
//         return 1
//     }

//     if (num[n]) {
// 　　　　return num[n];
// 　　}
//     const res = calcFib(n - 1) + calcFib(n - 2);
//     num[n] = res;
// 　　return res;
// }

// for(let i = 1; i < 50; i++){
//     let startTime = new Date().getTime()
//     // console.log(calcFib(i))
//     calcFib(i)
//     let endTime = new Date().getTime()
//     console.log("第" + i + "次耗时：" + (endTime - startTime))
// }

/* ======================= 优化 斐波那契 尾递归 ======================= */
// pre 上上次位置， res 上次位置
// function tailFib(pre, res, n) {
//     if (n <= 2) {
//         return res;
//     }
//     return tailFib(res, pre + res, n - 1);
// }

// for(let i = 1; i < 50; i++){
//     let startTime = new Date().getTime()
//     console.log(tailFib(1,1,i))
//     // tailFib(1,1,i)
//     let endTime = new Date().getTime()
//     console.log("第" + i + "次耗时：" + (endTime - startTime))
// }

/* ======================= 数组求和 ======================= */

// function sum(arr, total) {
//     if(arr.length === 1) {
//         return total
//     }
//     return sum(arr, total + arr.pop())
// }

/* ======================= 数组扁平化 ======================= */
// let a = [1,2,3,[1,2,3,[1,2,3]]]
// 变成
// let a = [1,2,3,1,2,3,1,2,3]
// 具体实现
// function flat(arr = [], result = []) {
//     arr.forEach(v => {
//         if(Array.isArray(v)) {
//             result = result.concat(flat(v, []))
//         }else {
//             result.push(v)
//         }
//     })
//     return result
// }

// console.log(flat(a))


/* ======================= 数组对象格式化 ======================= */
// let obj = {
//     a: '1',
//     b: {
//         c: '2',
//         D: {
//             E: '3'
//         }
//     }
// }
// // 转化为如下：
// let obj = {
//     a: '1',
//     b: {
//         c: '2',
//         d: {
//             e: '3'
//         }
//     }
// }

// // 代码实现
// function keysLower(obj) {
//     let reg = new RegExp("([A-Z]+)", "g");
//     for (let key in obj) {
//         if (obj.hasOwnProperty(key)) {
//             let temp = obj[key];
//             if (reg.test(key.toString())) {
//                 // 将修改后的属性名重新赋值给temp，并在对象obj内添加一个转换后的属性
//                 temp = obj[key.replace(reg, function (result) {
//                     return result.toLowerCase()
//                 })] = obj[key];
//                 // 将之前大写的键属性删除
//                 delete obj[key];
//             }
//             // 如果属性是对象或者数组，重新执行函数
//             if (typeof temp === 'object' || Object.prototype.toString.call(temp) === '[object Array]') {
//                 keysLower(temp);
//             }
//         }
//     }
//     return obj;
// };







