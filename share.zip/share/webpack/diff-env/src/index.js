const update = () => {
    const hash = window.location.hash || '#shop'
    const mainElement = document.querySelector('body')
    mainElement.innerHTML = ''
    if (hash === '#shop') {
        import('./shop/shop').then(({ default: shop }) => {
        mainElement.appendChild(shop())
        })
    } else if (hash === '#home') {
        import('./home/home').then(({ default: home }) => {
        mainElement.appendChild(home())
        })
    }
}

window.addEventListener('hashchange', update)
update()