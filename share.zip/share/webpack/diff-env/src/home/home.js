import './home.css'

export default () => {
    console.log('this is home')
    const box = document.createElement('div')
    const ele = document.createElement('div')
    const inp = document.createElement('input')

    ele.setAttribute('class', 'box-home')
    inp.setAttribute('class', 'inp-home')

    box.appendChild(ele)
    box.appendChild(inp)

    return box
}


