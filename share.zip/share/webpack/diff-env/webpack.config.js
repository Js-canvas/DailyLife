const path = require('path')
const { CleanWebpackPlugin } = require('clean-webpack-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')

module.exports = (env, argv) => {
    console.log('env: ', env)
    console.log('argv: ', argv)
    const config = {
        mode: 'none',
        entry: './src/index.js',
        output: {
            filename: 'bundle.js',
            path: path.join(__dirname, 'output')
        },
        module: {
            rules: [
                {
                    test: /\.css$/,
                    use: [
                        "style-loader",
                        "css-loader"
                    ]
                }
            ]
        },
        devServer: {
            compress: true, // 启用 gzip 压缩
            port: 9000,
            hot: true,
            open: true,
        },
        plugins: [
            new CleanWebpackPlugin(),
            new HtmlWebpackPlugin(
                {
                    title: 'index',
                    template: './temp.html',
                    filename: 'index.html',
                    hash: true,
                }
            ),
        ],
    }
    config.optimization = env.development ? {
        // 模块只导出被使用的成员
        usedExports: true,
        // 开启压缩
        minimize: true,
        // 尽可能合并每一个模块到一个函数中
        // concatenateModules: true,
    } : undefined

    return config
}