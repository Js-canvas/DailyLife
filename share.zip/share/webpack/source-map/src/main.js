const getText = () => {
    console.log('this is webpack111')
}

const divEle = document.createElement('div');
divEle.setAttribute('class', 'test')
document.body.appendChild(divEle);

getText();

console.log1('a')