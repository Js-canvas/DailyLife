const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
// const { CleanWebpackPlugin } = require('clean-webpack-plugin')
// const CopyWebpackPlugin = require('copy-webpack-plugin')

module.exports = {
    mode: 'none',
    entry: './src/main.js',
    output: {
        filename: 'bundle.js',
        path: path.join(__dirname, 'output')
    },
    plugins: [
        // new CleanWebpackPlugin(),
        // new CopyWebpackPlugin({
        //     patterns: [
        //         {
        //             from: path.join(__dirname, 'assets'),
        //             to: 'resource'
        //         }
        //     ]
        // }),
        new HtmlWebpackPlugin({
            title: 'webpack',
            src: './assets/images/logo.png',
            template: './temp.html'
        }),
    ],
    devServer: {
        static: {
            directory: path.join(__dirname, 'assets'),
            publicPath: '/assets'
        },
        compress: true, // 启用 gzip 压缩
        port: 9000,
        open: true,
        proxy: {
            '/output': 'http://localhost:9000',
            '/list': {
                target: 'http://localhost:9000',
                pathRewrite: { '^/list': '' },
            }
        }
    },
}