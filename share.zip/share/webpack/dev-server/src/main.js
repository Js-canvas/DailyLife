// import img from './assets/images/logo.png'

// const imgEle = document.createElement('img');
// imgEle.setAttribute('src', img)
// document.body.appendChild(imgEle);

console.log('this is webpack111')