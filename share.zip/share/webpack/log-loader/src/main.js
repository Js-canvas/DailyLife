import * as getLogs from './test.log'

console.log(getLogs('~'))