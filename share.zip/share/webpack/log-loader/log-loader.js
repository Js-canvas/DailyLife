module.exports = source => {
    // 加载到的模块内容
    const logStr = typeof source === 'string' ? source.replace(/\n|\r/g, '') : JSON.stringify(source).replace(/\n|\r/g, '');
    // 返回值就是最终被打包的内容
    const funcStr = `
        const logList = ${JSON.stringify(logStr)}.split(params || '~');
        return new Array(...logList)
    `
    return `module.exports = new Function('params', ${JSON.stringify(funcStr)})`
}