import {model1} from './model-1';
import {model2} from './model-2';
import './index.css'
import {clone} from 'lodash'

console.log('parcel !!!!', clone)

const box = document.createElement('div');
box.setAttribute('class', 'box');
document.body.appendChild(box)

model2(model1)