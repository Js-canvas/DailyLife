const path = require('path')
const { CleanWebpackPlugin } = require('clean-webpack-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

module.exports = {
    mode: 'none',
    entry: './src/index.js',
    output: {
        filename: 'bundle.js',
        path: path.join(__dirname, 'output')
    },
    module: {
        rules: [
            {
                test: /\.css$/,
                use: [
                    // MiniCssExtractPlugin.loader,
                    "style-loader",
                    "css-loader"
                ]
            }
        ]
    },
    devServer: {
        compress: true, // 启用 gzip 压缩
        port: 9000,
        hot: true,
        open: true,
    },
    plugins: [
        new CleanWebpackPlugin(),
        // new MiniCssExtractPlugin({
        //     filename: "[name]/[name].css",
        // }),
        new HtmlWebpackPlugin(
            {
                title: 'index',
                template: './temp.html',
                filename: 'index.html',
                hash: true,
            }
        ),
    ],
    optimization: {
        // 模块只导出被使用的成员
        usedExports: true,
        // 开启压缩
        // minimize: true,
        // 尽可能合并每一个模块到一个函数中
        // concatenateModules: true,
    }
}