import { ButtonB } from './Buttons'
import './main.css'

console.log('this is HMR')

const ele = document.createElement('div')
const inp = document.createElement('input')

ele.setAttribute('class', 'box')
inp.setAttribute('class', 'inp')

document.body.appendChild(ele)
document.body.appendChild(inp)
document.body.appendChild(ButtonB())




