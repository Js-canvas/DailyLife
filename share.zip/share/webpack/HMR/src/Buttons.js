export const ButtonA = () => document.createElement('button')
export const ButtonB = () => document.createElement('button')
export const ButtonC = () => document.createElement('button')
export const ButtonD = () => {
    console.log('this is d')
    return document.createElement('button')
}