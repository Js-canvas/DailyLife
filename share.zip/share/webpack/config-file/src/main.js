import createHeader from './header.js'

const header = createHeader()

document.body.append(header)