export const model2 = (params) => {
    console.log(`model2 show ${params}`)
}