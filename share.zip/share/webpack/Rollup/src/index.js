import {model1} from './model-1';
import {model2} from './model-2';

console.log('rollup !!!')

model2(model1)