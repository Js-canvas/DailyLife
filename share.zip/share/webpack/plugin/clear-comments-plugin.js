class ClearCommentsPlugin {
    apply(compiler) {
        compiler.hooks.emit.tap('ClearCommentsPlugin', compilation => {
        // compilation => 可以理解为此次打包的上下文
            for (const name in compilation.assets) {
                // 只处理 bungle.js 文件下的注释
                if (name === 'bundle.js') {
                    const contents = compilation.assets[name].source()
                    // ? 非贪婪模式，尽可能少的匹配注释字符
                    const noComments = contents.replace(/\/\*{2,}\/\s?/g, '')
                    compilation.assets[name] = {
                        source: () => noComments,
                        size: () => noComments.length
                    }
                }
            }
        })
    }
}

module.exports = ClearCommentsPlugin

