import './index.css'
import './common/common.css'
import { api } from './common/api'

console.log('this is Index', api.b)

const ele = document.createElement('div')
const inp = document.createElement('input')

ele.setAttribute('class', 'box')
inp.setAttribute('class', 'inp')

document.body.appendChild(ele)
document.body.appendChild(inp)




