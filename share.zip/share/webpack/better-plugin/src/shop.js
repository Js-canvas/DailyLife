import './shop.css'
import './common/common.css'
import { api } from './common/api'

console.log('this is Shop', api.c)

const ele = document.createElement('div')
const inp = document.createElement('input')

ele.setAttribute('class', 'box-shop')
inp.setAttribute('class', 'inp-shop')

document.body.appendChild(ele)
document.body.appendChild(inp)




