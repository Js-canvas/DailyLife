import './home.css'
import './common/common.css'
import { api } from './common/api'

console.log('this is Home', api.a)

const ele = document.createElement('div')
const inp = document.createElement('input')

ele.setAttribute('class', 'box-home')
inp.setAttribute('class', 'inp-home')

document.body.appendChild(ele)
document.body.appendChild(inp)




