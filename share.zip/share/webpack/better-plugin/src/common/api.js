export const api = {
    a:1,
    b:2,
    c:3
}