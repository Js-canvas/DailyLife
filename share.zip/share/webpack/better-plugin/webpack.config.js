const path = require('path')
const webpack = require('webpack')
const { CleanWebpackPlugin } = require('clean-webpack-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const OptimizeCssAssetsWebpackPlugin = require('optimize-css-assets-webpack-plugin')
const TerserWebpackPlugin = require('terser-webpack-plugin')

module.exports = {
    mode: 'none',
    entry: {
        index: './src/index.js',
        home: './src/home.js',
        shop: './src/shop.js',
    },
    output: {
        filename: '[name]/[name].bundle.js',
        path: path.join(__dirname, 'output')
    },
    module: {
        rules: [
            {
                test: /\.css$/,
                use: [
                    MiniCssExtractPlugin.loader,
                    "css-loader"
                ]
            }
        ]
    },
    devServer: {
        compress: true, // 启用 gzip 压缩
        port: 9000,
        hot: true,
        open: true,
    },
    plugins: [
        new CleanWebpackPlugin(),
        new MiniCssExtractPlugin({
            filename: "[name]/[name].css",
        }),
        new HtmlWebpackPlugin(
            {
                title: 'index',
                template: './temp.html',
                filename: 'index/index.html',
                chunks: ['index'], // 指定使用 index.bundle.js
                hash: true,
            }
        ),
        new HtmlWebpackPlugin(
            {
                title: 'home',
                template: './temp.html',
                filename: 'home/index.html',
                chunks: ['home'],
                hash: true,
            }
        ),
        new HtmlWebpackPlugin(
            {
                title: 'shop',
                template: './temp.html',
                filename: 'shop/index.html',
                chunks: ['shop'],
                hash: true,
            }
        ),
        new webpack.DefinePlugin({
            API_BASE_URL: JSON.stringify('https://iot.yyuap.com/')
        })
    ],
    optimization: {
        // 模块只导出被使用的成员
        // usedExports: true,
        // 开启压缩
        minimize: true,
        // 尽可能合并每一个模块到一个函数中
        // concatenateModules: true,
        // splitChunks: {
        //     // 自动提取所有公共模块到单独 bundle
        //     chunks: 'all',
        //     name: 'common',
        //     minSize: 0, // 拆分文件最小体积 默认 20000 byte
        // },
        minimizer: [
            new TerserWebpackPlugin(),
            new OptimizeCssAssetsWebpackPlugin()
        ]
    }
}