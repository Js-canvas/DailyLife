define([
    'jquery',
    './b.js'
], function($, b) {
    'use strict';
    var name = 'module-a';
    return {
        moduleA: function() {
            $('body').css('background-color', '#f00');
            console.log(`this is ${name}`)
            b.moduleB();
        }
    }
});
