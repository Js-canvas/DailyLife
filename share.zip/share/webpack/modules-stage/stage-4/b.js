define([], function() {
    'use strict';
    var name = 'module-b';
    return {
        moduleB: function() {
            console.log(`this is ${name}`)
        }
    }
});
