function moduleA () {
    console.log('this is module a')
}