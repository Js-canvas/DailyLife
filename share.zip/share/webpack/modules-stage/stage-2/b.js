window.moduleB = {
    data: 'module-b'
}