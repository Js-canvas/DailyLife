window.moduleA = {
    func: function() {
        console.log('this is module a')
    }
}