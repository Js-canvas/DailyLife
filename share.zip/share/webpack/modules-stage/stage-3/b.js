(function() {
    var name = 'module-b';
    window.moduleB = {
        func: function() {
            console.log(`this is ${name}`)
        }
    }
})()
