(function($) {
    var name = 'module-a';
    window.moduleA = {
        func: function() {
            $('body').css('background-color', '#f00');
            console.log(`this is ${name}`)
        }
    }
})(jQuery)
