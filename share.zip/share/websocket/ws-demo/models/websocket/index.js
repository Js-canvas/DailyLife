const WebSocket = require('ws')
const WebSocketServer = WebSocket.Server

function headerBeat() {
    this.isAlive = true;
}

function init() {
    // 创建 websocket 服务器 监听在 3002 端口
    const wss = new WebSocketServer({port: 3002})
    // 服务器被客户端连接
    wss.on('connection', (ws) => {
        ws.isAlive = true;
        ws.on('pong', headerBeat)
        ws.on('message', (message) => {
            console.log(ws.binaryType)
            if (ws.binaryType === 'nodebuffer') {
                // const nodebufferData = message.toJSON();
                // nodebufferData.timestamp = new Date().getTime();
                // const newNodebufferData = JSON.stringify(nodebufferData)
                // console.log(newNodebufferData)
                sendMsg(newNodebufferData)
                const str = Buffer.from(message, 'urf-8').toString() || '{}';
                const data = JSON.parse(str);
                data.timestamp = new Date().getTime();
                const newStr = JSON.stringify(data)
                sendMsg(newStr)
            } else if (ws.binaryType === 'arraybuffer') {
                const str = Buffer.from(message, 'urf-8').toString() || '{}';
                const data = JSON.parse(str);
                data.timestamp = new Date().getTime();
                const newStr = JSON.stringify(data)
                sendMsg(newStr)
            }
        })
        ws.on('close', () => {})
    })

    const sendMsg = (msg) => {
        wss.clients.forEach(ws => {
            ws.send(msg)
        })
    }

    const timer = setInterval(() => {
        wss.clients.forEach(ws => {
            if (ws.isAlive === false) {
                console.log('===close')
                return ws.terminate();
            }
            ws.isAlive = false;
            ws.ping('', false, true);
        })
    }, 10000);

    wss.on('close', () => {
        clearInterval(timer);
    })
}

module.exports = {
    init: init
}